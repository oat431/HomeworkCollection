package app;
public class StudentRegistrationInfo {
	public StudentInfo s;
	public SemesterAcademicRecord[] rec;
	
	public StudentRegistrationInfo()
	{
		rec = new SemesterAcademicRecord[24];
	}
	
	
}
