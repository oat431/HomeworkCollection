{\rtf1\ansi\ansicpg1252\cocoartf1038\cocoasubrtf360
{\fonttbl\f0\fnil\fcharset0 Monaco;\f1\fnil\fcharset0 LucidaGrande;}
{\colortbl;\red255\green255\blue255;}
{\*\listtable{\list\listtemplateid1\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{disc\}}{\leveltext\leveltemplateid1\'01\uc0\u8226 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listname ;}\listid1}
{\list\listtemplateid2\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{disc\}}{\leveltext\leveltemplateid101\'01\uc0\u8226 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listname ;}\listid2}
{\list\listtemplateid3\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{disc\}}{\leveltext\leveltemplateid201\'01\uc0\u8226 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{circle\}}{\leveltext\leveltemplateid202\'01\uc0\u9702 ;}{\levelnumbers;}\fi-360\li1440\lin1440 }{\listname ;}\listid3}}
{\*\listoverridetable{\listoverride\listid1\listoverridecount0\ls1}{\listoverride\listid2\listoverridecount0\ls2}{\listoverride\listid3\listoverridecount0\ls3}}
\paperw11900\paperh16840\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\ql\qnatural\pardirnatural

\f0\fs20 \cf0 Copyright (c) 2012, Laura Luppani (www.behance.net/luppa, lauluppani@gmail.com), True Type Font under the name of "Dekiru".\
\
\pard\pardeftab720\ql\qnatural
\cf0 Dekiru.ttf by Laura Luppani is licensed under a {\field{\*\fldinst{HYPERLINK "http://creativecommons.org/licenses/by-nc-nd/3.0/"}}{\fldrslt \ul Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License}}.\
Based on a work at {\field{\*\fldinst{HYPERLINK "http://www.behance.net/gallery/Dekiru-Typography-Catalogue/498169"}}{\fldrslt \ul www.behance.net}}\
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\ql\qnatural\pardirnatural
\cf0 \
-----------------------------------------------------------\
This license is copied below, and is also available at:\
http://creativecommons.org/licenses/by-nc-nd/3.0/\
-----------------------------------------------------------\
\
\pard\pardeftab720\sa280\ql\qnatural
\cf0 License\
\pard\pardeftab720\sa240\ql\qnatural
\cf0 THE WORK (AS DEFINED BELOW) IS PROVIDED UNDER THE TERMS OF THIS CREATIVE COMMONS PUBLIC LICENSE ("CCPL" OR "LICENSE"). THE WORK IS PROTECTED BY COPYRIGHT AND/OR OTHER APPLICABLE LAW. ANY USE OF THE WORK OTHER THAN AS AUTHORIZED UNDER THIS LICENSE OR COPYRIGHT LAW IS PROHIBITED.\
BY EXERCISING ANY RIGHTS TO THE WORK PROVIDED HERE, YOU ACCEPT AND AGREE TO BE BOUND BY THE TERMS OF THIS LICENSE. TO THE EXTENT THIS LICENSE MAY BE CONSIDERED TO BE A CONTRACT, THE LICENSOR GRANTS YOU THE RIGHTS CONTAINED HERE IN CONSIDERATION OF YOUR ACCEPTANCE OF SUCH TERMS AND CONDITIONS.\
\pard\pardeftab720\sa280\ql\qnatural
\cf0 You are free:\
\pard\tx220\tx720\pardeftab720\li720\fi-720\ql\qnatural
\ls1\ilvl0\cf0 {\listtext	\'95	}to Share \'97 to copy, distribute and transmit the work\
\pard\tx560\pardeftab720\ql\qnatural
\cf0 \
\pard\pardeftab720\sa280\ql\qnatural
\cf0 Under the following conditions:\
\pard\tx220\tx720\pardeftab720\li720\fi-720\sa240\ql\qnatural
\ls2\ilvl0\cf0 {\listtext	\'95	}Attribution \'97 You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work). \
{\listtext	\'95	}Noncommercial \'97 You may not use this work for commercial purposes. \
{\listtext	\'95	}No Derivative Works \'97 You may not alter, transform, or build upon this work. \
\pard\pardeftab720\sa280\ql\qnatural
\cf0 With the understanding that:\
\pard\tx220\tx720\pardeftab720\li720\fi-720\ql\qnatural
\ls3\ilvl0\cf0 {\listtext	\'95	}Waiver \'97 Any of the above conditions can be {\field{\*\fldinst{HYPERLINK "http://creativecommons.org/licenses/by-nc-nd/3.0/#"}}{\fldrslt \ul waived}} if you get permission from the copyright holder.\
{\listtext	\'95	}Public Domain \'97 Where the work or any of its elements is in the {\field{\*\fldinst{HYPERLINK "http://wiki.creativecommons.org/Public_domain"}}{\fldrslt \ul public domain}} under applicable law, that status is in no way affected by the license.\
{\listtext	\'95	}Other Rights \'97 In no way are any of the following rights affected by the license:\
\pard\tx940\tx1440\pardeftab720\li1440\fi-1440\ql\qnatural
\ls3\ilvl1\cf0 {\listtext	
\f1 \uc0\u9702 
\f0 	}Your fair dealing or {\field{\*\fldinst{HYPERLINK "http://wiki.creativecommons.org/Frequently_Asked_Questions#Do_Creative_Commons_licenses_affect_fair_use.2C_fair_dealing_or_other_exceptions_to_copyright.3F"}}{\fldrslt \ul fair use}} rights, or other applicable copyright exceptions and limitations;\
{\listtext	
\f1 \uc0\u9702 
\f0 	}The author's {\field{\*\fldinst{HYPERLINK "http://wiki.creativecommons.org/Frequently_Asked_Questions#I_don.E2.80.99t_like_the_way_a_person_has_used_my_work_in_a_derivative_work_or_included_it_in_a_collective_work.3B_what_can_I_do.3F"}}{\fldrslt \ul moral}} rights;\
{\listtext	
\f1 \uc0\u9702 
\f0 	}Rights other persons may have either in the work itself or in how the work is used, such as {\field{\*\fldinst{HYPERLINK "http://wiki.creativecommons.org/Frequently_Asked_Questions#When_are_publicity_rights_relevant.3F"}}{\fldrslt \ul publicity}} or privacy rights.\
}