package model;

public enum DamageType {
    physical,
    magical
}
