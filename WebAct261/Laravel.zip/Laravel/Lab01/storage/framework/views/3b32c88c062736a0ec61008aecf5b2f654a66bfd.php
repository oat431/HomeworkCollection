

<?php $__env->startSection('title','Friends list'); ?>

<?php $__env->startSection('content'); ?>
<button type="button" class="btn btn-success">
   <a href="friends/create" style="color: white;">Create</a>
</button>

<table class="table" style="margin-top: 2%;">
   <tr>
      <td>#</td>
      <td>Name</td>
      <td>E-Mail</td>
      <td>Gender</td>
      <td>Age</td>
      <td>Actions</td>
   </tr>

   <?php $__empty_1 = true; $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
   <tr>
      <td><?php echo e($friend['id']); ?></td>
      <td><?php echo e($friend['name']); ?></td>
      <td><?php echo e($friend['email']); ?></td>
      <td><?php echo e($friend['gender']); ?></td>
      <td><?php echo e($friend['age']); ?></td>
      <td>
         <?php echo e(Form::open(array('url' => 'friends/{id}','method'=>'get'))); ?>

         <?php echo e(Form::submit('Detail')); ?>

         <?php echo e(Form::close()); ?> |

         <?php echo e(Form::open(array('url' => 'friends/{id}','method'=>'put'))); ?>

         <?php echo e(Form::submit('Edit')); ?>

         <?php echo e(Form::close()); ?> |

         <?php echo e(Form::open(array('url' => 'friends/{id}','method'=>'delete'))); ?>

         <?php echo e(Form::submit('Delete')); ?>

         <?php echo e(Form::close()); ?>


      </td>
   </tr>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <h3 style="color: red;text-align:center">======No Data======</h3>

   <?php endif; ?>

</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work_Project\CMU\2ndYear\Sem1\InteractiveWeb\Lab\Laravel\Lab01\resources\views/friends/list.blade.php ENDPATH**/ ?>