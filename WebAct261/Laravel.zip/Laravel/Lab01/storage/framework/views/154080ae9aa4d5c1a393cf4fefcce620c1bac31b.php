

<?php $__env->startSection('title','Create new friends'); ?>

<?php $__env->startSection('content'); ?>

<?php echo e(Form::open(array('url' => 'friends','method'=>'post'))); ?>


<div class="form-group">
   <label>Name</label>
   <?php echo e(Form::text('name','',['class'=>'form-control','style'=>'width:50%'])); ?>

</div>

<div class="form-group">
   <label>E-Mail</label>
   <?php echo e(Form::email('email','',['class'=>'form-control','style'=>'width:50%'])); ?>

</div>

<div class="form-group">
   <?php echo e(Form::select('gender',['Male'=>'Male','Female'=>'Female'])); ?>

</div>

<div class="form-group">
   <?php echo e(Form::date('date',\Carbon\Carbon::now())); ?>

</div>

<!-- <div class="form-group form-check">
   <?php echo e(Form::checkbox('check','')); ?>

   <label>Check it out</label>
</div> -->
<div class="form-group">
   <?php echo e(Form::submit('Submit')); ?>

</div>
<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work_Project\CMU\2ndYear\Sem1\InteractiveWeb\Lab\Laravel\Lab01\resources\views/Friends/create.blade.php ENDPATH**/ ?>