

<?php $__env->startSection('title','Friends'); ?>

<?php $__env->startSection('content'); ?>
<table class="table">
   <tr>
      <td>#</td>
      <td>Name</td>
      <td>E-Mail</td>
      <td>Gender</td>
      <td>Age</td>
      <td>Actions</td>
   </tr>
   <?php $__currentLoopData = $friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
      <td><?php echo e($friend['id']); ?></td>
      <td><?php echo e($friend['name']); ?></td>
      <td><?php echo e($friend['email']); ?></td>
      <td><?php echo e($friend['gender']); ?></td>
      <td><?php echo e($friend['age']); ?></td>
      <td>Actions</td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Work_Project\CMU\2ndYear\Sem1\InteractiveWeb\Lab\Laravel\Lab01\resources\views/Friends/list.blade.php ENDPATH**/ ?>