@extends('layouts.master')

@section('title','Friends list')

@section('content')
<button type="button" class="btn btn-success">
   <a href="friends/create" style="color: white;">Create</a>
</button>

<table class="table" style="margin-top: 2%;">
   <tr>
      <td>#</td>
      <td>Name</td>
      <td>E-Mail</td>
      <td>Gender</td>
      <td>Age</td>
      <td>Actions</td>
   </tr>

   @forelse($friends as $friend)
   <tr>
      <td>{{$friend['id']}}</td>
      <td>{{$friend['name']}}</td>
      <td>{{$friend['email']}}</td>
      <td>{{$friend['gender']}}</td>
      <td>{{$friend['age']}}</td>
      <td>
         {{Form::open(array('url' => 'friends/{id}','method'=>'get'))}}
         {{Form::submit('Detail')}}
         {{Form::close() }} |

         {{Form::open(array('url' => 'friends/{id}','method'=>'put'))}}
         {{Form::submit('Edit')}}
         {{Form::close() }} |

         {{Form::open(array('url' => 'friends/{id}','method'=>'delete'))}}
         {{Form::submit('Delete')}}
         {{Form::close() }}

      </td>
   </tr>

   @empty
   <h3 style="color: red;text-align:center">======No Data======</h3>

   @endforelse

</table>
@endsection