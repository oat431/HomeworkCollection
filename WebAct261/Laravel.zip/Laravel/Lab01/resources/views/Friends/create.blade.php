@extends('layouts.master')

@section('title','Create new friends')

@section('content')

{{Form::open(array('url' => 'friends','method'=>'post'))}}

<div class="form-group">
   <label>Name</label>
   {{Form::text('name','',['class'=>'form-control','style'=>'width:50%'])}}
</div>

<div class="form-group">
   <label>E-Mail</label>
   {{Form::email('email','',['class'=>'form-control','style'=>'width:50%'])}}
</div>

<div class="form-group">
   {{Form::select('gender',['Male'=>'Male','Female'=>'Female'])}}
</div>

<div class="form-group">
   {{Form::date('date',\Carbon\Carbon::now())}}
</div>

<!-- <div class="form-group form-check">
   {{Form::checkbox('check','')}}
   <label>Check it out</label>
</div> -->
<div class="form-group">
   {{Form::submit('Submit')}}
</div>
{{ Form::close() }}
@endsection