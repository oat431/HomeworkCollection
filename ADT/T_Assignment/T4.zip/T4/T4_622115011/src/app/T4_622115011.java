package app;
import java.util.*;
public class T4_622115011 {
    public static void main(String[] args) throws Exception {
        Scanner Sc = new Scanner(System.in);
        int u[] = {12,5,10,15,31,20,25,2,40};

        System.out.print("Please enter number: ");
        int In = Sc.nextInt();
        Sc.close();
       if(LinearSearch(u, In) >= 0){
        System.out.println("Number "+ In + " is in index : " + LinearSearch(u,In) + " by " +(LinearSearch(u,In) + 1) +" step");
       }
       else{
        System.out.println("Cannot find index");
       }
       //System.out.println(LinearSearch(u, In));
    }

    public static int LinearSearch(int a[], int b) {
        int A = 0;
        for(int i = 0 ; i < a.length ; i++){
            
            if(a[i] == b){
             A = i;
             break;
            }

            else{
                A = -10;
            }
            
            
        }
        return A;
    }
}