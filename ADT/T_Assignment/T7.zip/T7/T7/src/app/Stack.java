package app;

class Stack{
    private int size = 0;
    private Integer[] Arr = new Integer[10];
    
    public int Re(){
        return size;
    }
    public void E(){
        for(int i = Arr.length-1 ; i >= 0 ; i --){
          System.out.println("Element "+ i +  ": " + Arr[i]);
        }
    }
    public void push(int a){
        Arr[size] = a;
        size++;
    }

    public int pop(){
        int keep = Arr[size-1];
        Arr[size-1] = null;
        size--;
        return keep;
    }

    public int peek(){
        int keep = Arr[size-1];
        return keep;
    }

    public String isEmpty(){
        if(size >= 0) return "Not empty";
        return "Empty";
    }

    public String isFull(){
        if(size == 10) return "Full";
        return "Not full";
    }
}