package app;

public class App {
    public static void main(String[] args) throws Exception {
        Stack Decha = new Stack();
        
        Decha.push(6);
        Decha.push(2);
        Decha.push(2);
        Decha.push(1);
        Decha.push(1);
        Decha.push(5);
        Decha.push(0);
        Decha.push(1);
        Decha.push(1);

        
        System.out.println("Peek: " + Decha.peek());
        System.out.println("Pop: " + Decha.pop());
        System.out.println("Pop: " + Decha.pop());
        System.out.println("Pop: " + Decha.pop());
        Decha.E();
        System.out.println("All element: " + Decha.Re());
    }
}