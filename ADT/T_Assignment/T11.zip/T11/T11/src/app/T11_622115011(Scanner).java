package app;
import java.util.*;
class T11_622115011 {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);  
        int no = sc.nextInt(); 

        for(int i = 1 ; i <= no ; i++){
            int size = sc.nextInt();
            int[][] arr = new int[size][size];
            for(int q = 0 ; q < size ; q++){
                String word = sc.next();
                for(int w = 0 ; w < size ; w++){
                    arr[q][w] = word.charAt(w)-'0';
                }
            }
            
            if(Xsym(size, arr) && Ysym(size, arr)) {
                System.out.println("YES");
            } else {
                System.out.println("NO");
            }
        }
        sc.close();
    }

    static boolean Xsym(int size, int arr[][]) {
        int L = 0;
        int R = size-1;
        boolean Res = true;
        while(L < R){
            for(int y = 0 ; y < size ; y++){
                if(arr[L][y] != arr[R][y]){
                    Res = false;
                    return Res;
                }
            }
            L++;
            R--;
        }
        Res = true;
        return Res;
    }

    static boolean Ysym(int size, int arr[][]){
        int L = 0;
        int R = size-1;
        boolean Res = true;
        while(L < R){
            for(int y = 0 ; y < size ; y++){
                if(arr[y][L] != arr[y][R]){
                    Res = false;
                    return Res;
                }
            }
            L++;
            R--;
        }
        Res = true;
        return Res;
    }
}