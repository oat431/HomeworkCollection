package app;

import java.util.ArrayList;

public class Queue{
     private int count = 0;
     private int maxQ = 30;
     ArrayList<Integer> Arr = new ArrayList<>();

public void Enqueue(int a){
    Arr.add(a);
    count++;
}

public Object Dequeue(){
    if(count==0){
        return "Cannot dequeue";
    }
    int tmp = Arr.remove(0);
    count--;
    return "Dequeue number: " + tmp;
}

public Object getSize(){
    return "Size at now: " + count;
}

public Object Front(){
    if(count == 0){
       return "Front not found";
    }

    else return "Front at now: " + Arr.get(0);
}

public Object Rear(){
    if(count == 0){
        return "Rear not found";
    }

    return "Rear at now: " + Arr.get(count-1);
}

public void isEmpty(){
    if(count == 0){
    System.out.println("This array is empty");
    }
    else System.out.println("This array is not empty");
}

public void getData(){
    System.out.println(Arr);
}

public void isFull(){
    if(count >= maxQ){
        System.out.println("This array is Full");
    }
    else System.out.println("This array is Not full");
}
}