package app;

public class App {
    public static void main(String[] args) throws Exception {
        Queue Decha = new Queue();
        System.out.println("=========================================");
        System.out.println("==================Queue==================");
        System.out.println("============[Max=Queue=is=30]============");
        System.out.println("=========================================");
        Decha.Enqueue(2);
        Decha.Enqueue(4);
        Decha.Enqueue(-1);
        Decha.Enqueue(3);
        Decha.Enqueue(5);
        Decha.Enqueue(9);
        Decha.getData();
        System.out.println(Decha.getSize());
        System.out.println(Decha.Front());
        System.out.println(Decha.Dequeue());
        System.out.println(Decha.Dequeue());
        Decha.getData();
        System.out.println(Decha.Front());
        System.out.println(Decha.Rear());
        System.out.println(Decha.getSize());
        Decha.isEmpty();
        Decha.isFull();
    }
}