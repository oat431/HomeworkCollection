package app;

import java.util.*;

public class T5_622115011 {
    public static void main(String[] args) throws Exception {
    Scanner Scw = new Scanner(System.in);
    Vector<String> Vec = new Vector<String>();
    System.out.print("Enter the words, use quit for stop: ");
        
        do{
            String in = Scw.nextLine();
            switch (in){
            case "quit":
            System.out.println("The reverse list is: \n");
                for(int a = (Vec.size()-1) ; a >= 0 ; a-- ){
                    System.out.println("- " + Vec.elementAt(a));
                }
                break;
            default: 
            Vec.add(in);
            }
        }
        while(Scw.hasNext());

    



}
    
}