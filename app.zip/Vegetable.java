package app;

public class Vegetable extends Food{
    public Vegetable(){
        setFoodName("Default Vegetable");
        setFoodType("Vegetable");
    }
}