package app;

public class Food{
    public Food(){foodName = "Default Food";}
	
    private String foodName;
    private int foodweight;
    private String foodType;
    
	public String getFoodName() {
		return foodName;
    }
    
    public void setFoodType(String type){
        this.foodType = type;
    }

    public String getFoodType(){
        if(foodType == null){
            return "";
        }
        return foodType;
    }

	public void setFoodName(String foodName) {
		this.foodName = foodName;
    }
    
	public int getFoodweight() {
		return foodweight;
    }
    
	public void setFoodweight(int foodweight) {
		this.foodweight = foodweight;
    }
    

}