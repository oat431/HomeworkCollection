package app;
public class Cat extends Animal{
    public Cat(){}
	
	public Cat(String n, int a) {
		super(n, a);
		setType("Cat");
    }
    
    @Override
	public String Eat(Food f)
	{
		if(f.getFoodType().equals("Meat"))
		{
			return "Thanks for feeding me " + f.getFoodType() + " as " + f.getFoodName();
		}else if(f.getFoodType().equals("Vegetable")){
            return "Why you feed this to me I hate it " + f.getFoodType() + " as " + f.getFoodName();
        }else if(f.getFoodType().equals("Water")){
            return "So fresh give me more this" + f.getFoodType() + " as " + f.getFoodName();
        }
		else{
            return "Cannot Eat Unknow Food";
        }
	}

}