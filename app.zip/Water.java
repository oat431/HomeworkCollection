package app;

public class Water extends Food{
    public Water(){
        setFoodName("default Water");
        setFoodType("Water");
    }
}