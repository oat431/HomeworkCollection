package app;
public class Dog extends Animal{
    public Dog(String n, int a) {
		super(n, a);
		setType("Dog");
    }
    
    @Override
	public String Eat(Food f)
	{
		if(f.getFoodType().equals("Meat"))
		{
			return "Thanks for feeding me " + f.getFoodType() + " as " + f.getFoodName();
		}else if(f.getFoodType().equals("Vegetable")){
            return "Thanks for feeding me " + f.getFoodType() + " as " + f.getFoodName();
        }else if(f.getFoodType().equals("Water")){
            return "So fresh give me more this" + f.getFoodType() + " as " + f.getFoodName();
        }
		else{
            return "Cannot Eat Unknow Food";
        }
	}
}