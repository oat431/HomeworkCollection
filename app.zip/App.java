package app;

public class App {
    public static void main(String[] args) throws Exception {
        Food f1 = new Food();
		Vegetable f2 = new Vegetable();
		f2.setFoodName("Veggie Mixed");
		Meat f3 = new Meat();
		System.out.println(f2.getClass().getName());
		Animal a1 = new Animal();
		String result7 = a1.Eat(f1);
		System.out.println(result7);
		String result8 = a1.Eat(f2);
		System.out.println(result8);
		String result9 = a1.Eat(f3);
		System.out.println(result9);
		
		Cat c = new Cat();
		c.setName("cat 1");		
		String result1 = c.Eat(f1);
		System.out.println(result1);
		String result2 = c.Eat(f2);
		System.out.println(result2);
		String result3 = c.Eat(f3);
		System.out.println(result3);
		
		Animal c2 = new Cat();
		String result4 = c2.Eat(f1);
		System.out.println(result4);
		String result5 = c2.Eat(f2);
		System.out.println(result5);
		String result6 = c2.Eat(f3);
		System.out.println(result6);

        System.out.println("========================My test case===================");
        System.out.println();
        System.out.println();

        Food someFood = new Food();
        Food someMeat = new Meat();
        Food someVet = new Vegetable();
        Food someWater = new Water();

        Animal cat = new Cat("Visa",16);
        Animal dog = new Dog("Lucky",14);
        Animal pig = new Pork("Sukorn",10);
        Animal tiger = new Tiger("Po",24);

        System.out.println("Cat test case");
        System.out.println(cat.Eat(someFood));
        System.out.println(cat.Eat(someMeat));
        System.out.println(cat.Eat(someVet));
        System.out.println(cat.Eat(someWater));
        System.out.println();
        System.out.println();
        System.out.println("Dog test case");
        System.out.println(dog.Eat(someFood));
        System.out.println(dog.Eat(someMeat));
        System.out.println(dog.Eat(someVet));
        System.out.println(dog.Eat(someWater));
        System.out.println();
        System.out.println();
        System.out.println("Pork test case");
        System.out.println(pig.Eat(someFood));
        System.out.println(pig.Eat(someMeat));
        System.out.println(pig.Eat(someVet));
        System.out.println(pig.Eat(someWater));
        System.out.println();
        System.out.println();
        System.out.println("Tiger test case");
        System.out.println(tiger.Eat(someFood));
        System.out.println(tiger.Eat(someMeat));
        System.out.println(tiger.Eat(someVet));
        System.out.println(tiger.Eat(someWater));
        System.out.println(tiger.Eat(cat));
        System.out.println(tiger.Eat(dog));
        System.out.println(tiger.Eat(pig));
        

    }
}