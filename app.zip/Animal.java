package app;

public class Animal{
    private String Name;
	private String Gender;
	private String Color;
	private int Age;
    private String type;
    
	public Animal(){}
	public Animal(String n,int a)
	{
		Age = a;Name = n;
	}
	
	public String getName() {
		return Name;
    }
    
	public void setName(String name) {
		Name = name;
    }
    
	public String getGender() {
		return Gender;
    }
    
	public void setGender(String gender) {
		Gender = gender;
    }
    
	public String getColor() {
		return Color;
    }
    
	public void setColor(String color) {
		Color = color;
    }
    
	public int getAge() {
		return Age;
    }
    
	public void setAge(int age) {
		Age = age;
	}
    
    public void setType(String type){
        this.type = type;
    }

    public String getType(){
        return this.type;
    }

	public String Eat(Food f)
	{
		return "Thanks for feeding me the "+ f.getFoodName();
	}

    public String Eat(Animal n){
        return "Thanks for feeding me the "+ n.getName();
    }
}