package app;

public class Tiger extends Animal{
    public Tiger(String n, int a) {
		super(n, a);
		setType("Tiger");
    }
    
    @Override
	public String Eat(Food f)
	{
		if(f.getFoodType().equals("Meat"))
		{
			return "Thanks for feeding me " + f.getFoodType() + " as " + f.getFoodName();
		}else if(f.getFoodType().equals("Vegetable")){
            return "Why you feed this to me I hate it " + f.getFoodType() + " as " + f.getFoodName();
        }else if(f.getFoodType().equals("Water")){
            return "So fresh give me more this" + f.getFoodType() + " as " + f.getFoodName();
        }
		else{
            return "Cannot Eat Unknow Food";
        }
    }
    
    @Override
    public String Eat(Animal n){
        if(n.getType().equals("Cat")){
            return "Yummy this kitty is so Yummy";
        }else if(n.getType().equals("Dog")){
            return "Yummy this Doggy is so Yummy";
        }else if(n.getType().equals("Pork")){
            return "Yummy this Pigggy is so Yummy";
        }
        return "Nahh it not even a real animal";
    }
}