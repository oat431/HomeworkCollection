package app;

public class Pork extends Animal{
    public Pork(String n, int a) {
		super(n, a);
		setType("Pork");
    }
    
    @Override
	public String Eat(Food f)
	{
		if(f.getFoodType().equals("Meat"))
		{
			return "I hate this food get away from my mouse " + f.getFoodType() + " as " + f.getFoodName();
		}else if(f.getFoodType().equals("Vegetable")){
            return "Thanks for feeding me " + f.getFoodType() + " as " + f.getFoodName();
        }else if(f.getFoodType().equals("Water")){
            return "Noooo Please let it flow out side me " + f.getFoodType() + " as " + f.getFoodName();
        }
		else{
            return "Cannot Eat Unknow Food";
        }
	}
}