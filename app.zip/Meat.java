package app;

public class Meat extends Food{
    public Meat(){
        setFoodName("Default Meat");
        setFoodType("Meat");
    }


}