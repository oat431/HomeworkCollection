package app;

import java.util.ArrayList;

class Subject{
    ArrayList<String> No = new ArrayList<String>();
    ArrayList<String> Title = new ArrayList<String>();
    ArrayList<Double> Credit = new ArrayList<Double>();
    ArrayList<Double> Grade = new ArrayList<Double>();
    double All = 0.0;
    double AllCredit = 0.0;
    double AllCreditCut = 0.0;
    double gpa = 0.00;
    
    
    public void AddS(String a , String b , double c , double d){
        No.add(a);
        Title.add(b);
        Credit.add(c);
        Grade.add(d);
    }

    public void Operation(){
        String A = "";
        for(int i = 0 ; i < No.size() ; i++){
        A = "  No." + (i+1) + " "+ No.get(i) + " " + Title.get(i) + " Credit: " + Credit.get(i) + " GPA: " + Grade.get(i);
        System.out.println(A);
        }
        
        for(int i = 0 ; i < Credit.size() ; i++){   
            AllCredit += Credit.get(i);
        }
        
        for(int i = 0 ; i < Credit.size() ; i++){   
            if(Grade.get(i) == 0.00){
                Credit.remove(i);
                Grade.remove(i);
            }
        AllCreditCut += Credit.get(i);
        All += Credit.get(i) * Grade.get(i);
    }
    gpa = All / AllCreditCut;
    System.out.println("All Credit = " + AllCredit + ", Now Credit = " + AllCreditCut);
    System.out.printf("GPA = %.2f\n", gpa);
    }
      
    
        





    }




