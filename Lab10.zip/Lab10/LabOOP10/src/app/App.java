package app;

public class App {
    public static void main(String[] args) throws Exception {
    System.out.println("Student ID: 552115099");

    GPAX gg = new GPAX();
    Subject Sem1 = new Subject();
    System.out.println("========================================================================================");
    System.out.println("Semester 1 / 2559");
        Sem1.AddS("001101", "FUNDAMENTAL ENGLISH 1", 3.00, 3.00);
        Sem1.AddS("206113", "CAL FOR SOFTWARE ENGINEERING", 3.00, 3.50);
        Sem1.AddS("751100", "ECONOMIC FOR EVERY LIFE", 3.00, 1.50);
        Sem1.AddS("951100", "MODERN LIFE AND ANIMATION", 3.00, 4.00);
        Sem1.AddS("953103", "PROGRAMMING LOGICAL THINKING", 2.00, 4.00);
        Sem1.AddS("953211", "COMPUTER ORGANIZATION", 3.00, 2.50);
    Sem1.Operation();
    gg.AddSUb(Sem1);
    gg.CalG();
    System.out.println("========================================================================================");
    System.out.println("Semester 2 / 2559");
    Subject Sem2 = new Subject();
        Sem2.AddS("001102"," FUNDAMENTAL ENGLISH 2",3.00,3.00);
        Sem2.AddS("011251"," LOGIC",3.00,3.00);
        Sem2.AddS("953102"," ADT&PROBLEM SOLVING",3.00,2.50);
        Sem2.AddS("953104"," WEB UI DESiGN & DEVELOP",2.00,2.00);
        Sem2.AddS("953202"," INTRODUCTION TO SE",3.00,2.00);
        Sem2.AddS("953231"," OBJECT OREINTED PROGRAMING",3.00,3.00);
        Sem2.AddS("955100"," LEARNING TOROUGH ACT",1.00,4.00);
    Sem2.Operation(); 
    gg.AddSUb(Sem2);
    gg.CalG();
    System.out.println("========================================================================================");
    System.out.println("Semester 1 / 2560");
    Subject Sem3 = new Subject();
    Sem3.AddS("001201", "CRIT READ AND EFFEC WRITE", 3.00, 0.00);
    Sem3.AddS("206281", "DISCRETE MATHEMATICS", 3.00, 3.00);
    Sem3.AddS("953212", "DB SYS & DB SYS DESIGN", 3.00, 2.50);
    Sem3.AddS("953233", "PROGRAMMING METHODOLOGY", 3.00, 2.50);
    Sem3.AddS("953261", "INTERACTIVE WEB DEVELOPMENT", 2.00, 2.50);
    Sem3.AddS("953361", "COMP NETWORK & PROTOCOLS", 3.00, 1.5);
    Sem3.Operation();
    gg.AddSUb(Sem3);
    gg.CalG();
    System.out.println("========================================================================================");

    }





}