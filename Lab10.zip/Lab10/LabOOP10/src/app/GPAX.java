package app;

import java.util.ArrayList;

class GPAX {
    ArrayList<Subject> OOO = new ArrayList<Subject>();
    Subject GPA = new Subject();
    Subject Credit = new Subject();
    double gpax2 = 0.0;
    
    public void AddSUb(Subject a){
        OOO.add(a);
    }
    public void CalG(){
    double gpa2 = 0.0;
        for(int i = 0 ; i < OOO.size() ; i++){
            gpa2 += OOO.get(i).gpa;
    }
    gpax2 = gpa2/OOO.size();
    System.out.printf("GPAX = %.2f\n",gpax2);
}

}